import React from 'react';
import axios from 'axios';
import { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.css';

const F_Registration = () => {
    
    const [user, setUser] = useState({
        area: "",
        faddress: "",
        fcontact: "",
        fname: "",
        password: ""
      });



      const { area,faddress,fcontact,fname,
        password } = user;
       
      const onInputChange = e => {
        setUser({ ...user, [e.target.name]: e.target.value });
      };
       
      const onSubmit = async e => {
        e.preventDefault();
        await axios.post("http://localhost:8082/farmer/register",user);
        alert('Data Inserted');
        window.location.reload(false);
        // this.history.push("/Home");
      };


  return (
   <>
    <div >
      <div class="row">  
       <div className="col-sm-4 mx-auto shadow p-5">
        <h2 className="text-center mb-4">Farmer Registartion</h2>
        <form onSubmit={e => onSubmit(e)}>
          <div className="form-group">
            <input
              type="text"
              className="form-control form-control-lg mb-2"
              placeholder="Enter Farmers Name"
              name="fname"
              value={fname}
              onChange={e => onInputChange(e)}
            />
          </div>
          <div className="form-group">
            <input
              type="text"
              className="form-control form-control-lg mb-2"
              placeholder="Enter Farmers Address"
              name="faddress"
              value={faddress}
              onChange={e => onInputChange(e)}
            />
          </div>
          <div className="form-group">
            <input
              type="text"
              className="form-control form-control-lg mb-2"
              placeholder="Enter Farmers Contact Number"
              name="fcontact"
              value={fcontact}
              onChange={e => onInputChange(e)}
            />
          </div>
          <div className="form-group">
            <input
              type="text"
              className="form-control form-control-lg mb-2"
              placeholder="Enter Farms Area in Acres"
              name="area"
              value={area}
              onChange={e => onInputChange(e)}
            />
          </div>
          <div className="form-group">
            <input
              type="password"
              className="form-control form-control-lg mb-2"
              placeholder="Enter Contractor Password"
              name="password"
              value={password}
              onChange={e => onInputChange(e)}
            />
          </div>
          <button className="btn btn-primary btn-block">Add Farmer</button>
        </form>
      </div>
    </div>
  </div>  
   </>
  )
}

export default F_Registration;