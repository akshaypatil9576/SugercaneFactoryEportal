import './About_us.css'
import React from 'react'
import 'bootstrap/dist/css/bootstrap.css'
import image1 from './Images/image1.JPG'
import 'bootstrap/dist/css/bootstrap.css';
import 'bootstrap';
import 'bootstrap/dist/js/bootstrap.bundle'
import 'bootstrap/dist/js/bootstrap.esm';
import 'bootstrap/dist/js/bootstrap';
import image2 from './Images/image2.jpg'
import image3 from './Images/image3.jpeg'
import image4 from './Images/image4.jpeg'

const About_us = () => {


  return (<>

<div class="about-section">
  <h1>About Us </h1>
  <p  class="fw-bolder fst-italic">We are the people who connect farmers to factory …!</p>
  <p class="fw-bolder fst-italic">Agriculture is the noblest of all alchemy; for it turns earth, and even manure, into gold, conferring upon its cultivator the additional reward of health.
</p>
</div>
<div class='container text-centre'><h2>Our Team</h2></div>

{/* <div class="card">
  <img src={image1} class="card-img-top" />
  <div class="card-body">
    <h5 class="card-title">Card title</h5>
    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
    <a href="#" class="btn btn-primary">Go somewhere</a>
  </div>
</div> */}

<div class="row">
  <div class="column">
    <div class="card">
      <img src={image1} alt="Jane" />
      <div class="container">
        <h5>Abhishek Chandankere</h5>
        <p class="title">Developer</p>
        <p>Infoway Technologies Private Limited ( Authorized C-DAC Training Centre )</p>
        <p>achandankere@gmail.com</p>
        <p><button class="button">+91 8668223535</button></p>
      </div>
    </div>
  </div>
  <div class="column">
    <div class="card">
      <img src={image2} alt="Jane" />
      <div class="container">
        <h2>Akshay B Patil</h2>
        <p class="title">Developer</p>
        <p>Infoway Technologies Private Limited ( Authorized C-DAC Training Centre )</p>
        <p>akkip9576@gmail.com</p>
        <p><button class="button">+91 9766512236</button></p>
      </div>
    </div>
  </div>
  <div class="column">
    <div class="card">
      <img  src={image3} alt="Jane" />
      <div class="container">
        <h2>Kartik Gore</h2>
        <p class="title">Developer</p>
        <p>Infoway Technologies Private Limited ( Authorized C-DAC Training Centre )</p>
        <p>kartikkumarg99@gmail.com</p>
        <p><button class="button">+91 7769894668</button></p>
      </div>
    </div>
  </div>
  <div class="column">
    <div class="card">
      <img src ={image4}  alt="Jane" />
      <div class="container">
        <h2>Akshay P Patil</h2>
        <p class="title">Developer</p>
        <p>Infoway Technologies Private Limited ( Authorized C-DAC Training Centre )</p>
        <p>aakshaypatil33@gmail.com</p>
        <p><button class="button">+91 9381742068</button></p>
      </div>
    </div>
  </div>


 </div> 








  
  
  </>
   )
}

export default About_us