import React from 'react';
import axios from 'axios';
import { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.css';

const Registration = () => {
  const [user, setUser] = useState({
    caddress: "",
    ccontact: "",
    cname: "",
    manpower: "",
    password: "",
    vehicalInfo: "",
  });
 
  const { caddress,ccontact,cname,manpower
    ,password,vehicalInfo } = user;
   
  const onInputChange = e => {
    setUser({ ...user, [e.target.name]: e.target.value });
  };
   
  const onSubmit = async e => {
    e.preventDefault();
    await axios.post("http://localhost:8082/contractor/register",user);
    alert('Data Inserted');
    window.location.reload(false);
    // history.push("/");
  };


  return (
   <>
   <div >
      <div class="row">  
       <div className="col-sm-4 mx-auto shadow p-5">
        <h3 className="text-center mb-4">Contractor Registartion</h3>
        <form onSubmit={e => onSubmit(e)}>
          <div className="form-group">
            <input
              type="text"
              className="form-control form-control-lg mb-2"
              placeholder="Enter Contractor Name"
              name="cname"
              value={cname}
              onChange={e => onInputChange(e)}
            />
          </div>
          <div className="form-group">
            <input
              type="text"
              className="form-control form-control-lg mb-2"
              placeholder="Enter Contractor Address"
              name="caddress"
              value={caddress}
              onChange={e => onInputChange(e)}
            />
          </div>
          <div className="form-group">
            <input
              type="text"
              className="form-control form-control-lg mb-2"
              placeholder="Enter Contractor Contact Number"
              name="ccontact"
              value={ccontact}
              onChange={e => onInputChange(e)}
            />
          </div>
          <div className="form-group">
            <input
              type="text"
              className="form-control form-control-lg mb-2"
              placeholder="Enter Available Vehicles Information"
              name="vehicalInfo"
              value={vehicalInfo}
              onChange={e => onInputChange(e)}
            />
          </div>
          <div className="form-group">
            <input
              type="password"
              className="form-control form-control-lg mb-2"
              placeholder="Enter Contractor Password"
              name="password"
              value={password}
              onChange={e => onInputChange(e)}
            />
          </div>
          <div className="form-group">
            <input
              type="text"
              className="form-control form-control-lg mb-2"
              placeholder="Enter Available Manpower"
              name="manpower"
              value={manpower}
              onChange={e => onInputChange(e)}
            />
          </div> 
          <button className="btn btn-primary btn-block" color='black'>Add Contractor</button>
        </form>
      </div>
    </div>
  </div>  
   </>
  )
}

export default Registration