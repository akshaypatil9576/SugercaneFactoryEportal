import React from 'react'

const F_Update = () => {
  return (
    <div>F_Update</div>
  )
}

export default F_Update