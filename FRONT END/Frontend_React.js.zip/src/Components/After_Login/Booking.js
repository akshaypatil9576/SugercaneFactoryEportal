import React from 'react';
import axios from 'axios';
import { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.css';
import { Navigate } from 'react-router-dom';

const Booking = () => {



  const [user, setUser] = useState({
    fid: "",
    cid: "",
   status: "",
   schedule_dt:""
  });
 
  const { fid,cid,status,schedule_dt } = user;
   
  const onInputChange = e => {
    setUser({ ...user, [e.target.name]: e.target.value });
  };
   
  const onSubmit = async e => {
    e.preventDefault();
    await axios.post("http://localhost:8082/farmer/bookContractor",user).then((response)=>{
        alert(response.data)
        window.location.reload(false)
        
    })
    
  };




  return (
   <>
    <div >
      <div class="row">  
       <div className="col-sm-4 mx-auto shadow p-5">
        <h2 className="text-center mb-4">Harvesting Schedule</h2>
        <form onSubmit={e => onSubmit(e)}>
          <div className="form-group">
            <input
              type="text"
              className="form-control form-control-lg mb-2"
              placeholder="Enter Farmer Id"
              name="fid"
              value={fid}
              onChange={e => onInputChange(e)}
            />
          </div>
          <div className="form-group">
            <input
              type="text"
              className="form-control form-control-lg mb-2"
              placeholder="Enter Contractor Id"
              name="cid"
              value={cid}
              onChange={e => onInputChange(e)}
            />
          </div>
          <div className="form-group">
            <input
              type="text"
              className="form-control form-control-lg mb-2"
              placeholder="Enter Booking Status"
              name="status"
              value={status}
              onChange={e => onInputChange(e)}
            />
          </div>
          <div className="form-group">
            <input
              type="text"
              className="form-control form-control-lg mb-2"
              placeholder="Schedule a Date"
              name="schedule_dt"
              value={schedule_dt}
              onChange={e => onInputChange(e)}
            />
          </div>
          <button className="btn btn-primary btn-block">Book Contractor</button>
        </form>
      </div>
    </div>
  </div>  
   
   </>
  )
}

export default Booking