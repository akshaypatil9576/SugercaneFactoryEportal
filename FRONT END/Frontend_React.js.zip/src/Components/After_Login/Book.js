import { useParams } from 'react-router-dom'
import React from 'react'

const Book = () => {

    const {id} = useParams();
    console.log(id)
  return (
    <>
    <h1>thsi is Book</h1>
    
    </>
  )
}

export default Book