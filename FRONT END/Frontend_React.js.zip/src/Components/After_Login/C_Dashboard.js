import React from 'react'
import axios from 'axios'
import { useState , useEffect} from 'react';
import 'bootstrap/dist/css/bootstrap.css'
import {Navigate,useNavigate} from 'react-router-dom'
import {Link} from 'react-router-dom'



const C_Dashboard = () => {

    const [contractor,setContractor] = useState([]);
    const [farmer , setFarmer] = useState([]);
    const [harvesting , setHarvesting] = useState([]);

    useEffect(()=>{
    },[])

    const Navigate = useNavigate();
    const onLogout = async e =>{
      Navigate('/Home')
      window.localStorage.clear();
      // console.log('working')
    }

    const getallContractor = async e => {
      await axios.get("http://localhost:8082/contractor/getallContractor").then((response)=>{
        setContractor(response.data)
      })
      };

      const getallFarmer = async e => {
        await axios.get("http://localhost:8082/farmer/getallfarmer").then((response)=>{
          setFarmer(response.data)
        })
        };

        const getHarvesting = async e => {
          await axios.get("http://localhost:8082/contractor/harvestingScheduling").then((response)=>{
            setHarvesting(response.data)
          })
          };



  return (
    <>

<nav class="navbar background">
        <ul class="nav-list">
           
            <li><button onClick={getallContractor} type='button' class="btn btn-success" color='black'>List of Contractors</button></li>
            <li><button onClick={getallFarmer} type='button' class="btn btn-success" color='black'>List of Farmer</button></li>
            <li><button onClick={getHarvesting} type='button' class="btn btn-success" color='black'>List of Schedule</button></li>
            <li><button onClick={onLogout} class='btn btn-danger'>Logout</button></li>
        </ul>
 
        {/* <div class="rightNav">
            <input type="text" name="search" id="search"/>
            <button class="btn btn-secondary ">Search</button>
        </div> */}
    </nav> 


    <div class='container'>
     <table class='table table-dark border shadow table-striped table-bordered'>
       <thead class='thead-light'>
         <tr>
           <th scope='col'>Id</th>
           <th scope='col'>Name</th>
           <th scope='col'>Address</th>
           <th scope='col'>Contact</th>
           <th scope='col'>Labour</th>
           <th scope='col'>Vehicles</th>
         </tr>
       </thead> 
       <tbody>
         {contractor.map((contractor)=>
         <tr key={contractor.cid}>
           <td>{contractor.cid}</td>
           <td>{contractor.cname}</td>
           <td>{contractor.caddress}</td>
           <td>{contractor.ccontact}</td>
           <td>{contractor.manpower}</td>
           <td>{contractor.vehicalInfo}</td>
         </tr>         
         )}
       </tbody>
     </table>
    </div>

    <div class='container'>
      <h3>Farmer List</h3>
     <table class='table table-dark border shadow table-striped table-bordered'>
       <thead class='thead-light'>
         <tr>
           <th scope='col'>Id</th>
           <th scope='col'>Name</th>
           <th scope='col'>Address</th>
           <th scope='col'>Contact</th>
           <th scope='col'>Area</th>
           <th scope='col'>Date & Time</th>
         </tr>
       </thead> 
       <tbody>
         {farmer.map((farmer)=>
         <tr key={farmer.fid}>
           <td>{farmer.fid}</td>
           <td>{farmer.fname}</td>
           <td>{farmer.faddress}</td>
           <td>{farmer.fcontact}</td>
           <td>{farmer.area}</td>
           <td>{farmer.created_on}</td>
         </tr>         
         )}
       </tbody>
     </table>
    </div>


    <div class='container'>
      <h3> Scheduling List</h3>
     <table class='table table-dark border shadow table-striped table-bordered'>
       <thead class='thead-light'>
         <tr>
           <th scope='col'>Id</th>
           <th scope='col'>Contractor Id</th>
           <th scope='col'>Farmer Id</th>
           <th scope='col'>Booking Date</th>
           <th scope='col'>Status</th>
           <th scope='col'>Scheduled Date</th>
         </tr>
       </thead> 
       <tbody>
         {harvesting.map((harvesting)=>
         <tr key={harvesting.hid}>
           <td>{harvesting.hid}</td>
           <td>{harvesting.cid}</td>
           <td>{harvesting.fid}</td>
           <td>{harvesting.hdate}</td>
           <td>{harvesting.status}</td>
           <td>{harvesting.schedule_dt}</td>
         </tr>         
         )}
       </tbody>
     </table>
    </div>




    </>
  )
}

export default C_Dashboard