import React from 'react'
import axios from 'axios'
import { useState , useEffect} from 'react';
import 'bootstrap/dist/css/bootstrap.css'
import {Navigate,useNavigate} from 'react-router-dom'
import { useParams } from 'react-router-dom';
import { Link } from 'react-router-dom';








const A_Dashboard = () => {

    const [ contractor , setContractor ] = useState([]);
    const [ farmer, setFarmer ] = useState([]);
    const [ admin , setAdmin ] = useState([]);
    const [harvesting , setHarvesting] = useState([]);

    useEffect(()=>{
    },[])

    const Navigate = useNavigate();
    const onLogout = async e =>{
      Navigate('/Home')
      window.localStorage.clear();
      // console.log('working')
    }

    const getallContractor = async e => {
      await axios.get("http://localhost:8082/contractor/getallContractor").then((response)=>{
        setContractor(response.data)
      })
      };

      const getallFarmer = async e => {
        await axios.get("http://localhost:8082/farmer/getallfarmer").then((response)=>{
          setFarmer(response.data)
        })
        };

        const getallAdmin = async e => {
          await axios.get("http://localhost:8082/admin/getallAdmin").then((response)=>{
            setAdmin(response.data)
          })
          };

          const getHarvesting = async e => {
            await axios.get("http://localhost:8082/contractor/harvestingScheduling").then((response)=>{
              setHarvesting(response.data)
            })
            };

      const addAdmin = async e => {
          Navigate('/A_Registration')
      }

      function Delete_C(id){
        axios.delete(`http://localhost:8082/contractor/deleteContractor/${id}`).then((response)=>{
           alert(JSON.stringify(response.data));
          //  getallContractor();
           window.location.reload(false);
        })
      }

      function Delete_F(id){
        axios.delete(`http://localhost:8082/farmer/deleteFarmer/${id}`).then((response)=>{
           alert(JSON.stringify(response.data));
          //  getallContractor();
           window.location.reload(false);
        })
      }

      function Delete_A(id){
        axios.delete(`http://localhost:8082/admin/deleteAdmin/${id}`).then((response)=>{
           alert(JSON.stringify(response.data));
          //  getallContractor();
           window.location.reload(false);
        })
      }

      function Update_C(id){
        console.log(id)
        Navigate('/C_Update')
      }

     

     


  return (
    <>

<nav class="navbar background">
        <ul class="nav-list">
           
            <li><button onClick={getallContractor} type='button' class="btn btn-success" color='black'>List of Contractors</button></li>
            <li><butto onClick={getallFarmer} class='btn btn-success'>List of Farmers</butto></li>
            <li><button onClick={getHarvesting} type='button' class="btn btn-success" color='black'>List of Schedule</button></li>
            <li><butto onClick={getallAdmin} class='btn btn-success'>List of Admin</butto></li>
            <li><button onClick={addAdmin} class='btn btn-secondary'>Add Admin</button></li>
            <li><button onClick={onLogout} class='btn btn-danger'>Logout</button></li>
        </ul>
 
        {/* <div class="rightNav">
            <input type="text" name="search" id="search"/>
            <button class="btn btn-secondary ">Search</button>
        </div> */}
    </nav> 



    <div class='container'>
    <h3>Contractors List</h3>

     <table class='table table-dark border shadow table-striped table-bordered'>
       <thead class='thead-light'>
         <tr>
           <th scope='col'>Id</th>
           <th scope='col'>Name</th>
           <th scope='col'>Address</th>
           <th scope='col'>Contact</th>
           <th scope='col'>Labour</th>
           <th scope='col'>Vehicles</th>
           <th scope='col'>Action</th>
         </tr>
       </thead> 
       <tbody>
         {contractor.map((contractor, i )=>
         <tr key={i}>
           <td>{contractor.cid}</td>
           <td>{contractor.cname}</td>
           <td>{contractor.caddress}</td>
           <td>{contractor.ccontact}</td>
           <td>{contractor.manpower}</td>
           <td>{contractor.vehicalInfo}</td>
           <td>
               <button onClick={()=>Delete_C(contractor.cid)} class='btn btn-danger mr-6'>Delete</button>
               
           </td>
         </tr>
         
         )}
       </tbody>
     </table>
    </div>


    
    <div class='container'>
    <h3>Farmers List</h3>
     <table class='table table-dark border shadow table-striped table-bordered'>
       <thead class='thead-light'>
         <tr>
           <th scope='col'>Id</th>
           <th scope='col'>Name</th>
           <th scope='col'>Address</th>
           <th scope='col'>Contact</th>
           <th scope='col'>Area</th>
           <th scope='col'>Date & Time</th>
           <th scope='col'>Action</th>
         </tr>
       </thead> 
       <tbody>
         {farmer.map((farmer)=>
         <tr key={farmer.fid}>
           <td>{farmer.fid}</td>
           <td>{farmer.fname}</td>
           <td>{farmer.faddress}</td>
           <td>{farmer.fcontact}</td>
           <td>{farmer.area}</td>
           <td>{farmer.created_on}</td>
           <td>
               <button onClick={()=>Delete_F(farmer.fid)} class='btn btn-danger mr-6'>Delete</button>
               
           </td>
         </tr>
         )}
       </tbody>
     </table>
    </div>


    <div class='container'>
    <h3>Admins List</h3>
     <table class='table table-dark border shadow table-striped table-bordered'>
       <thead class='thead-light'>
         <tr>
           <th scope='col'>Id</th>
           <th scope='col'>Name</th>
           <th scope='col'>Contact</th>
           <th scope='col'>Date & Time</th>
           <th scope='col'>Action</th>
         </tr>
       </thead> 
       <tbody>
         {
           admin.map((admin)=>
           <tr key={admin.aid}>
             <td>{admin.aid}</td>
             <td>{admin.aname}</td>
             <td>{admin.acontact}</td>
             <td>{admin.created_on}</td>
             <td>
               <button onClick={()=>Delete_A(admin.aid)} class='btn btn-danger mr-6'>Delete</button>
             
           </td>
           </tr>
            
           
           )
         }
       </tbody>
     </table>
    </div>

    <div class='container'>
      <h3> Scheduling List</h3>
     <table class='table table-dark border shadow table-striped table-bordered'>
       <thead class='thead-light'>
         <tr>
           <th scope='col'>Id</th>
           <th scope='col'>Contractor Id</th>
           <th scope='col'>Farmer Id</th>
           <th scope='col'>Booking Date</th>
           <th scope='col'>Status</th>
           <th scope='col'>Scheduled Date</th>
         </tr>
       </thead> 
       <tbody>
         {harvesting.map((harvesting)=>
         <tr key={harvesting.hid}>
           <td>{harvesting.hid}</td>
           <td>{harvesting.cid}</td>
           <td>{harvesting.fid}</td>
           <td>{harvesting.hdate}</td>
           <td>{harvesting.status}</td>
           <td>{harvesting.schedule_dt}</td>
         </tr>         
         )}
       </tbody>
     </table>
    </div>





    </>
  )
}

export default A_Dashboard