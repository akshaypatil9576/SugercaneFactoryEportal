import './Dashboard.css'
import React from 'react'
import 'bootstrap/dist/css/bootstrap.css';
import 'bootstrap';
import 'bootstrap/dist/js/bootstrap.bundle'
import 'bootstrap/dist/js/bootstrap.esm';
import 'bootstrap/dist/js/bootstrap';
import logo from './Images/logo.jpeg'
import pdf from './Images/Info.pdf'

const Dashboard = () => {

  let red = require("./Images/red.png");
  return (<>



	<div class="container">
		
		<div class="sidebar">
			<nav>
				<ul>
					<li><a href="#">NEWS</a></li>
					<li><a href="#">About</a></li>
					<li><a href="#">Social</a></li>
					<li><a href="#">Contact</a></li>
				</ul>
			</nav>
		</div>

		<div class="main-content">
			<h1>Dashboard</h1>
			<p>जय जवान जय किसान ..! </p>
			<div class="panel-wrapper">
				<div class="panel-head">
          <img src={red} width='15' height='15'></img> घडामोडी 
				</div>
				<div class="panel-body" >
          <ui>
            <li>
            महाराष्ट्र सहकारी साखर कारखानदारी घोटाळा: लिलाव सुरूच आहे राज्य सरकारला.		
            </li>
            <li>
            'इथेनॉल मिश्रण कार्यक्रमामुळे अतिरिक्त साखरेचा साठा मोठ्या प्रमाणात कमी होईल'</li>
            <li>
            महाराष्ट्रातील ऊस उत्पादकांना या हंगामात ₹5,000 कोटी एफआरपी मिळेल   </li>
            <li>
            15 डिसेंबरपर्यंत 175 कारखान्यांनी गळीत हंगाम सुरू केला असून 232.98 लाख टन उसाचे गाळप केले आहे.            </li>
            <li>
			देशांतर्गत (एक्स-मिल) किमती जास्त असल्याने सध्याच्या वैधानिक किमान विक्री किंमत ₹31/किलो या वाढीव सुधारणा करण्याची साखर उद्योगाची मागणी केंद्राने शुक्रवारी नाकारली. तसेच उद्योगांना नियंत्रित प्रणालीतून पुढे जाण्यास सांगितले.            </li>
          </ui>
        </div>
			</div>
			<div class="panel-wrapper">
				<div class="panel-head">
				<img src={red} width='15' height='15'></img> ऊस शेती बद्दल माहिती
				</div>
				<div class="panel-body">
				भारतातील ऊस लागवडीसाठी महत्त्वाचे प्रदेश/ झोन भारतामध्ये ऊस लागवडीचे दोन वेगळे कृषी-हवामान क्षेत्र आहेत.
उदा., उष्णकटिबंधीय आणि उपोष्णकटिबंधीय. तथापि, पाच कृषी-हवामान झोन प्रामुख्याने विविध विकासाच्या उद्देशाने ओळखले गेले आहेत. 
ते आहेत (i) उत्तर पश्चिम विभाग (ii) उत्तर मध्य विभाग (iii) उत्तर पूर्व विभाग (iv) द्वीपकल्पीय क्षेत्र (v) किनारी क्षेत्र. 
उष्णकटिबंधीय प्रदेश देशातील एकूण ऊस क्षेत्र आणि उत्पादनाच्या सुमारे 45% आणि 55% सामायिक आहे ,
 अनुक्रमे 77 टन/हेक्टर (2011-12) च्या सरासरी उत्पादकतेसह. उप-उष्णकटिबंधीय प्रदेश एकूण क्षेत्रफळाच्या
 सुमारे 55% आणि 45% आहे आणि ऊस उत्पादनाची सरासरी उत्पादकता सुमारे 63 टन/हेक्टर आहे (2011-12).
			<div class="container">
				
				<a class="link-primary" href={pdf} target="_blank" rel="noreferrer">
					Download Pdf
				</a>
				<p>
					ऊस शेती बद्दल अधिक माहितीसाठी वरील पीडीएफ डाउनलोड करा.  
				</p>
				</div>

				</div>
			</div>
			<div class="panel-wrapper">
				<div class="panel-head">
				<img src={red} width='15' height='15'></img> सरकारी योजना 
				</div>
				<div class="panel-body" id='news'>
			
			<ui>
				<li>
				प्रधानमंत्री कृषी सिंचन योजना - प्रती थेंब अधिक पिक (सूक्ष्म सिंचन घटक).
				</li>
				<li>
				राष्ट्रीय अन्न सुरक्षा अभियान अन्नधान्य, तेलबिया, ऊस व कापूस.
				</li>
				<li>
				बिरसा मुंडा कृषी क्रांती योजना (आदिवासी उप योजना / आदिवासी उप योजना बाह्य).
				</li>
				<li>
				डॉ. बाबासाहेब आंबेडकर कृषी स्वावलंबन योजना.
				</li>
				<li>
				भाऊसाहेब फुडकर फळबाग लागवड योजना.
				</li>
				<li>
				राज्य कृषी यांत्रिकीकरण योजना.
				</li>
				<li>
				मुख्यमंत्री शाश्वत कृषी सिंचन योजना.
				</li>
			</ui>

				</div>
			</div>
		</div>
	</div>

  
   
   </>
  )
}

export default Dashboard