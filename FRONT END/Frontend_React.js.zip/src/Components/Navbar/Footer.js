import React from 'react'
import './Footer.css'
import 'bootstrap/dist/css/bootstrap.css'


const Footer = () => {
  return (
   <>
   <div className='main-footer'>
       <div className='container'>
           <div className='row'>
               {/* column 1 */}
               <div className='col'>
                   <h5>PORTAL</h5>
                   <ul className="list-unstyled">
                       <li>020 4131 2111</li>
                       <li>3rd Floor, Commerce Centre,</li>
                       <li>Paud Road, Kothrud,</li>
                       <li>Pune, Maharashtra 411038.</li>
                   </ul>
               </div>
               {/* column 2 */}
               <div className='col'>
                   <h5>SUPPORT</h5>
                   <ul className='list-styled'>
                       <li>Getting Started Guide</li>
                       <li>Support Centre</li>
                       <li>Learn More</li>
                   </ul>
               </div>
               {/* column 3 */}
               <div className='col'>
                   <h5>COMPANY</h5>
                   <ul className='list-styled'>
                       <li>Privacy Policy</li>
                       <li>Terms of Use</li>
                       <li>Updates & Release</li>
                       <li>Sitemap</li>
                   </ul>
               </div>
               {/* column 4 */}
               <div className='col'>
                   <h5>Social Media Handles</h5>
                   <ul className='list-styles'>
                       <li>facebook   <i class="fab fa-facebook-f"></i> </li>
                       <li>instagram  <i class="fab fa-instagram"></i></li>
                       <li>Google <i class="fab fa-google"></i></li>
                       <li>twitter  <i class="fab fa-twitter"></i></li>

                   </ul>

               </div>
           </div>
           <hr/> 
           <div className='row'>
               <p className='col-sm'>
                   &copy; {new Date().getFullYear} E-Portal for Sugarcane Factory | All Rights Reserved | Terms of Service | Privacy |        

                    


               </p>

           </div>
       </div>
   </div>
   
   </>
  )
}

export default Footer