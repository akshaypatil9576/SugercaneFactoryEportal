
import React from 'react'
import Demo_nav from './Demo_nav'



const Hpage = () => {
  return (

    <>
    {/* <Navbar></Navbar> */}
    {/* <F_Registrtation></F_Registrtation> */}
    <Demo_nav></Demo_nav>
    

    
   

    </>
  )
}

export default Hpage