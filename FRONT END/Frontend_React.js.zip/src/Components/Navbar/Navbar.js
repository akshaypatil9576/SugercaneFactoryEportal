import {Link} from 'react-router-dom'
import React from 'react'
import "./Navbar.css"
import {FaHome ,FaIndustry} from 'react-icons/fa'

const navbar = () => {
return (
   <nav className="drop-down" class="first">
       <h2 className="eportal">Sugarcane Factory E-Portal</h2>
       <ul className='nav-links mb-0'>
           <Link to="/Home" className='home'>
               <li><FaHome/>Home</li>
           </Link>
           <Link to="/Dashboard" className='dashboard'>
               <li>Dashboard</li>
           </Link>
           <Link to="/About_us" className='about_us'>
               <li>About Us</li>
           </Link>
           <Link to="/Login" className='login '>
               <li>Login</li>
           </Link>
           <Link to="/Registration" className='registration'>
               <li>Register</li>
           </Link>
     </ul>
 </nav>
  )
}

export default navbar