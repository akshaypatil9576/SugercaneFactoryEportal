import React from 'react'
import {Link} from 'react-router-dom'
// import logo from '../Images/logo.jpeg'
import "./Navbar.css"
import {FaHome ,FaIndustry} from 'react-icons/fa'
import 'bootstrap/dist/css/bootstrap.css';
import 'bootstrap';
import 'bootstrap/dist/js/bootstrap.bundle'
import 'bootstrap/dist/js/bootstrap.esm';
import 'bootstrap/dist/js/bootstrap';





const Demo_nav = () => {

    

 
  return (
  <>
      <nav className="drop-down" class="first">
       <h2 className="eportal"> Sugarcane Factory E-Portal</h2>
       <ul className='nav-links mb-0'>
           <Link to="/Home" className='home'>
               <li><FaHome/>Home</li>
           </Link>
           <Link to="/Dashboard" className='dashboard'>
               <li>Dashboard</li>
           </Link>
           <Link to="/About_us" className='about_us'>
               <li>About Us</li>
           </Link>
        <li class="nav-item dropdown">
          <button class="nav-link dropdown-toggle btn-info login" data-bs-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">Login</button>
          <div class="dropdown-menu">
            <a class="dropdown-item" href="/Login">Admin</a>
            <a class="dropdown-item" href="/F_login">Farmer</a>
            <a class="dropdown-item" href="/C_login">Contractor</a>
          </div>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle btn-info login" data-bs-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">Registartion</a>
          <div class="dropdown-menu">
            <a class="dropdown-item" href="/F_Registration">Farmer</a>
            <a class="dropdown-item" href="/Registration">Contractor</a>
          </div>
        </li>
           
     </ul>
 </nav>  


{/* 
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="/Home"> E-Portal for Sugarcane Factory </a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="/Home">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="/Dashboard">Dashboard</a>
      </li>
      <li class="nav-item dropdown">
         <a class="nav-link dropdown-toggle" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            Login
         </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
            <a class="dropdown-item" href="/Login">Login</a>
            <a class="dropdown-item" href="#">Another action</a>
            <a class="dropdown-item" href="#">Something else here</a>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="/Registration" tabindex="-1" aria-disabled="true">Registartion</a>
      </li>
      <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" id='navdropdown' data-toggle="dropdown" >Registartion</a>
        <div class="dropdown-menu" aria-labelledby='navdropdown'>
            <a class="dropdown-item" href='#'>Registartion</a>
            <a class="dropdown-item" href='#'>Registartion</a>
            <a class="dropdown-item" href='#'>Registartion</a>
        </div>

      </li>
    </ul>
  </div>
</nav>   */}


{/* 
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Navbar</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarColor01" aria-controls="navbarColor01" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarColor01">
      <ul class="navbar-nav me-auto">
        <li class="nav-item">
          <a class="nav-link active" href="/Home">Home
            <span class="visually-hidden">(current)</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="/Dashboard">Dashboard</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Pricing</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="/Login">Login</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">Dropdown</a>
          <div class="dropdown-menu">
            <a class="dropdown-item" href="#">Action</a>
            <a class="dropdown-item" href="#">Another action</a>
            <a class="dropdown-item" href="#">Something else here</a>
            <div class="dropdown-divider"></div>
            <a class="dropdown-item" href="#">Separated link</a>
          </div>
        </li>
      </ul>
      <form class="d-flex">
        <input class="form-control me-sm-2" type="text" placeholder="Search"/>
        <button class="btn btn-secondary my-2 my-sm-0" type="submit">Search</button>
      </form>
    </div>
  </div>
</nav> */}
  </>
  )
}

export default Demo_nav