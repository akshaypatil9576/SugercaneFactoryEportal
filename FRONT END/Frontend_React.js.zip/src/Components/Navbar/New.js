import React, { Component } from 'react'
import axios from 'axios'
import "./New.css"
import Table from 'react-bootstrap/Table'

export default class New extends Component {

  state={
    contractors: []
  }

  componentDidMount(){
    try {

    axios.get('http://localhost:8082/contractor/getallContractor')
    .then((res)=>{
      console.log(res.data)
      this.setState({ contractors: res.data})
    })
      
    } catch (error) {
      console.log(error)
      
    }
  }



  render() {
    return (
      <>
      <h3 align='center'></h3>
        {
          this.state.contractors.map(contractor=><>
              
          
          </>)
          
          
            
        }
      </>
    )
  }
}
