import React, { useState , useEffect } from 'react'
import axios from 'axios';
import {Navigate,useNavigate} from 'react-router-dom'
import {FaWpforms,FaUserAlt} from 'react-icons/fa'
import {RiLockPasswordFill,RiLoginBoxFill} from 'react-icons/ri'
import Cookies from 'universal-cookie'

const C_login = () => {

  const [user,setUser]= useState({
    username: "",
    password: ""
  })

  const { username , password } = user

  const onInputChange = e => {
    setUser({ ...user, [e.target.name]: e.target.value });
  };

   const Navigate = useNavigate();

 
  
const onSubmit = async e => {
   e.preventDefault();

  await axios.post('http://localhost:8082/v1/api/login/contractorlogin',user).then((response)=>{

  let value = JSON.stringify(response.data)
  console.log(response.data);
  
  if(value==="true"){
    console.log('successful');
    // window.location.href("/Home");
    alert(` Valid credetials....   Welcome ${username}`)
    Navigate("/C_Dashboard");
    localStorage.setItem("username",username);
    Cookies.set("username",username)
  }else{
    console.log('unsuccessful');
    // window.location.href("/About_us");
    alert("Invalid Credentials........")
    window.location.reload(false)
  }

  });

  
}


  return (
   <>

<div >
      <div class="row">  
       <div className="col-sm-4 mx-auto shadow p-5">
        <h3 className="text-center mb-4"><FaWpforms/>  Contractor Login</h3>
        <form onSubmit={e => onSubmit(e)}>
          <h4><FaUserAlt/> USERNAME</h4>
        <div className="form-group">
            <input
              type="text"
              className="form-control form-control-lg mb-2"
              placeholder="Enter Username"
              name="username"
              value={username}
              onChange={e => onInputChange(e)}
            />
          </div>

           <h4><RiLockPasswordFill/> PASSWORD</h4>
          <div className="form-group">
            <input
              type="password"
              className="form-control form-control-lg mb-2"
              placeholder="Enter Password"
              name="password"
              value={password}
              onChange={e => onInputChange(e)}
            />
          </div>
          <button className="btn btn-primary btn-block"><RiLoginBoxFill/>  Login</button>
        </form>
      </div>
    </div>
  </div>  





   </>
  )
}

export default C_login