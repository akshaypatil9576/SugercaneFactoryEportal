import React from 'react'


const handleName = () =>{
    const name="rudra"
    return name
  }
  
  const handleClick = () =>{
    alert("clicked the button")
  }

  const handleClick1 = (name) =>{
    alert(`${name} clicked the button`)
  }

  const handleClick2 = (e) =>{
    alert(e.target.innerText)
  }

const Content = () => {
  return (
    <div>
         <p>
        hello, {handleName()}
      </p>

      <p>
        <button className='btn btn-primary' onClick={handleClick}> click me</button><br></br>
        <button className='btn btn-primary' onClick={()=>handleClick1(`abhi`)}> click me</button><br></br>
        <button className='btn btn-primary' onDoubleClick={(e)=>handleClick2(e)}> click me</button><br>
        </br>
      </p>
    </div>
  )
}

export default Content