import './App.css';
// import Content from './Content';
import { BrowserRouter as Router,Route, Routes } from 'react-router-dom'
import Hpage from './Components/Navbar/Hpage';
import Home from './Components/Home';
import Dashboard from './Components/Dashboard';
import Login from './Components/Login';
import About_us from './Components/About_us';
// import New from './Components/Navbar/New';
import New from './Components/Navbar/New';
import Registration from './Components/Registration';
import Footer from './Components/Navbar/Footer';
import A_Registration from './Components/A_Registration';
import F_Registration from './Components/F_Registration';
import F_login from './Components/F_login';
import C_login from './Components/C_login';
import F_Dashboard from './Components/After_Login/F_Dashboard';
import A_Dashboard from './Components/After_Login/A_Dashboard';
import C_Dashboard from './Components/After_Login/C_Dashboard';
import C_Update from './Components/After_Login/C_Update';
import Booking from './Components/After_Login/Booking';

  


function App() {



  return (
    <>
    <div className='page-container'>
      <div className='content-wrap'>

    <Router>
    <Hpage></Hpage>

     
   <Routes>
     <Route path='/Home' element={<Home/>} ></Route>
     <Route path='/Dashboard' element={<Dashboard/>} exact ></Route>
     <Route path='/Login' element={<Login/>} exact ></Route>
     <Route path='/About_us' element={<About_us/>} exact ></Route>
     <Route path='/Registration' element={<Registration/>} exact ></Route>
     {/* <Route path='/A_Registration' element={<A_Registration/>} exact ></Route> */}
     <Route path='/A_Registration' element={<A_Registration/>} exact ></Route>
     <Route path='/F_Registration' element={<F_Registration/>} exact ></Route>
     <Route path='/F_login' element={<F_login/>} exact ></Route>
     <Route path='/C_login' element={<C_login/>} exact ></Route>
     <Route path='/F_Dashboard' element={<F_Dashboard/>} exact ></Route>
     <Route path='/A_Dashboard' element={<A_Dashboard/>} exact ></Route>
     <Route path='/C_Dashboard' element={<C_Dashboard/>} exact ></Route>
     <Route path='/C_Update/:id' element={<C_Update/>} exact ></Route>
     <Route path='/Booking' element={<Booking/>} exact ></Route>


     
     
   </Routes> 


     {/* <Routes>
       <Route exact path='/' element={<Home/>}>
         <Home/>
         </Route>
       <Route exact path='/Dashboard' element={<Dashboard/>}>
         <Dashboard/>
         </Route>
       <Route exact path='/Login' element={<Login/>}>
         <Login/>
         </Route>
       <Route exact path='/About_us' element={<About_us/>}>
         <About_us/>
         </Route>

     </Routes>  */}

      {/* <New></New> */}
      <New></New>

     {/* <Content></Content> */}
      
   
    </Router>
   

      </div>
      <Footer></Footer>
    </div>



    
    </>
  );
}

export default App;
